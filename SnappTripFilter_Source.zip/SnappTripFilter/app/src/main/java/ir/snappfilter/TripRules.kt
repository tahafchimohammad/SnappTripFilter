package ir.snappfilter

data class Trip(val fareToman: Long, val tripMinutes: Double, val tripKm: Double, val pickupMinutes: Double, val pickupKm: Double)
data class Decision(val accepted: Boolean, val reasons: List<String>, val farePerMinute: Double)

object TripRules {
    fun evaluate(t: Trip): Decision {
        val reasons = mutableListOf<String>()
        val rate = if (t.tripMinutes > 0) t.fareToman / t.tripMinutes else 0.0
        if (rate <= 11_000) reasons += "کرایه هر دقیقه باید بیشتر از ۱۱٬۰۰۰ تومان باشد"
        if (t.tripKm > t.tripMinutes / 2.0) reasons += "مسافت سفر باید حداکثر نصف زمان سفر باشد"
        if (t.pickupMinutes >= 5.0) reasons += "زمان رسیدن به مبدأ باید کمتر از ۵ دقیقه باشد"
        if (t.pickupKm >= 2.0) reasons += "فاصله تا مبدأ باید کمتر از ۲ کیلومتر باشد"
        return Decision(reasons.isEmpty(), reasons, rate)
    }
}
