package ir.snappfilter

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class SnappAccessibilityService : AccessibilityService() {
    private var badge: TextView? = null
    private var lastText = ""
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        // Limit collection to Snapp Driver. Package id should be verified on the actual phone.
        if (!pkg.contains("snapp", ignoreCase = true)) return
        val root = rootInActiveWindow ?: return
        val parts = mutableListOf<String>()
        fun walk(node: android.view.accessibility.AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add)
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add)
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        val text = parts.distinct().joinToString(" | ")
        if (text == lastText || text.isBlank()) return
        lastText = text
        val trip = TripTextParser.parse(text) ?: run { show("اطلاعات سفر کامل خوانده نشد", false); return }
        val decision = TripRules.evaluate(trip)
        if (decision.accepted) show("سفر مناسب است ✓", true)
        else show("سفر رد شود ✕", false)
    }
    private fun show(message: String, good: Boolean) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (badge == null) {
            badge = TextView(this).apply { textSize = 16f; setPadding(28, 18, 28, 18); setTextColor(0xffffffff.toInt()) }
            val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = 120
            try { wm.addView(badge, p) } catch (_: Exception) { badge = null; return }
        }
        badge?.text = message
        badge?.setBackgroundColor(if (good) 0xff16834a.toInt() else 0xffb3261e.toInt())
    }
    override fun onInterrupt() {}
    override fun onDestroy() { try { badge?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}; badge = null; super.onDestroy() }
}
