package ir.snappfilter

/** Conservative parser for visible Persian/Arabic/Latin digits. Real Snapp layouts vary;
 * unknown or ambiguous values are rejected rather than guessed. */
object TripTextParser {
    private fun normalize(s: String) = s.map { c -> when (c) {
        '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'; '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
        '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'; '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
        '٫' -> '.'; '٬' -> ','; else -> c
    } }.joinToString("")
    private fun numberNear(text: String, labels: List<String>, unit: String): Double? {
        val n = normalize(text)
        for (label in labels) {
            val idx = n.indexOf(label)
            if (idx >= 0) {
                val tail = n.substring(idx + label.length).take(45)
                val m = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*$unit").find(tail)
                    ?: Regex("([0-9]+(?:[.,][0-9]+)?)").find(tail)
                if (m != null) return m.groupValues[1].replace(",", "").toDoubleOrNull()
            }
        }
        return null
    }
    fun parse(raw: String): Trip? {
        val text = normalize(raw)
        val fare = numberNear(text, listOf("کرایه", "مبلغ", "تومان"), "(?:تومان)?")?.toLong() ?: return null
        val minutes = numberNear(text, listOf("مدت سفر", "زمان سفر", "دقیقه"), "(?:دقیقه)?") ?: return null
        val km = numberNear(text, listOf("مسافت سفر", "کیلومتر سفر"), "(?:کیلومتر|km)?") ?: return null
        val pickupMin = numberNear(text, listOf("رسیدن به مسافر", "تا مبدأ", "تا مبدا"), "(?:دقیقه)?") ?: return null
        val pickupKm = numberNear(text, listOf("فاصله تا مبدأ", "فاصله تا مبدا"), "(?:کیلومتر|km)?") ?: return null
        if (fare <= 0 || minutes <= 0) return null
        return Trip(fare, minutes, km, pickupMin, pickupKm)
    }
}
