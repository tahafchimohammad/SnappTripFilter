package ir.snappfilter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 40, 32, 24); gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(TextView(this).apply { text = "فیلتر سفر اسنپ\n\nشرایط انتخاب:\n۱) کرایه هر دقیقه بیشتر از ۱۱٬۰۰۰ تومان\n۲) مسافت حداکثر نصف زمان سفر\n۳) رسیدن به مبدأ کمتر از ۵ دقیقه\n۴) فاصله تا مبدأ کمتر از ۲ کیلومتر\n\nاین نسخه آزمایشی فقط متن‌های قابل‌دسترسی صفحه را می‌خواند؛ اگر اسنپ متن‌ها را در دسترس‌پذیری ارائه نکند، تشخیص انجام نمی‌شود."; textSize = 17f })
        root.addView(Button(this).apply { text = "فعال‌کردن سرویس خواندن صفحه"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(Button(this).apply { text = "مجوز نمایش روی برنامه‌ها"; setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)) } }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }
}
